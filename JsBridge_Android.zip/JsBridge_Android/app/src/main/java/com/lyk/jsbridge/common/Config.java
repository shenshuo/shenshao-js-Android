package com.lyk.jsbridge.common;

/**
 * Created by qingliang on 16/10/31.
 */
public class Config {
    public static final String APP_ID = "10008768";                                 // 替换APP_ID
    public static final String SECRET_ID = "AKIDN8lBPUYSHuNdkCAjhVhnhQwISHyumQvd";  // 替换SECRET_ID
    public static final String SECRET_KEY = "jV6rTt782nU4hgaN3bkkXBbzGNI1a0oS";     // 替换SECRET_KEY
}
