package com.lyk.jsbridge;

/**
 * Created by xuezj on 2017/4/16.
 */

public interface OnBooleanListener {
    void onClick(boolean bln);
}
