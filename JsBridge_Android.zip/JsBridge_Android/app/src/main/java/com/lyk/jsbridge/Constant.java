 package com.lyk.jsbridge;

 public class Constant {

     public static final String APP_ID = "wx9a54b4bfda0b887b";

     // 全局显示隐藏开关
     public static final boolean on_off = false;

     // */ 手势密码点的状态
     public static final int POINT_STATE_NORMAL = 0; // 正常状态

     public static final int POINT_STATE_SELECTED = 1; // 按下状态

     public static final int POINT_STATE_WRONG = 2; // 错误状态
     // 交易
     public static final String RET_CODE_SUCCESS = "0000";// 0000 交易成功
     public static final int BASE_ID = 0;
     public static final int BANNER_GOBANKLIST = 5;
     public static final String USERROLE  = "INVESTOR";
     public static final String USERROLE2  = "SUPPLIER";
     public static final int RQF_PAY = BASE_ID + 1;
     public static final String RET_CODE_PROCESS = "2008";// 2008 交易处理中
     public static final String RESULT_PAY_SUCCESS = "SUCCESS";
     public static final String RESULT_PAY_PROCESSING = "PROCESSING";
     public static final String ZHUJI = "https://m.rmbbox.com/";
     public static final String ZHUJI2 = "http://preview.rmbbox.com/";
     public static final String ZHUJI3 = "http://8012.rmbboxs.cn/";
     public static String CESHI =  "http://fsngrok.viphk.ngrok.org/";
     public static String LIANGYU = "http://10.10.1.229:8083/";
     public static String GUOTIANXING="http://10.10.1.173:8080/";
     public static String ZHANGYANG = "http://10.10.1.193:8083/";
     public static String MENGHUIGAO = "http://fsngrok.viphk.ngrok.org/";
     public static String MENGHUIGAO2 = "http://192.168.40.63:8083/";
     public static String ZHAICHONGCHONG = "http://192.168.40.5:8080/";
     public static String ZHAOQIANG = "http://192.168.40.244:8881/";
     public static String MAYUE = "http://10.10.1.232:8083/";
     public static String WANGJIAOJIAO="http://10.10.1.226:8083/";
     public static String MY="file:///android_asset/Untitled1.html";
     public static String HECHENGWEN="http://192.168.30.243:8077/";
     public static String QQNumber = "1695173542";// 腾讯优图开发者账号（QQ号）
     public static String AppID = "10079696";
     public static String SecretID = "AKIDKlJvdRYJQUgy1ArUdklr0EXwRrFbdLlC";
     public static String SecretKey = "w09siGi8Sho061lFbqvpcEfYL0UmvwnS";
     public static int EXPIRED_SECONDS = 2592000;// 过期时间戳
     public static final String URL =ZHUJI2;



 }
