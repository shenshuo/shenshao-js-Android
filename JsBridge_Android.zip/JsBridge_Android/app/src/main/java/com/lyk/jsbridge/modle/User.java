package com.lyk.jsbridge.modle;

/**
 * Created by LIUYONGKUI726 on 2016-06-01.
 */
public class User {
    private String location ;
    private String name = "Bruce";

    public User() {
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
